
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Cita;
import utilidades.ConexionBD;

public class CitaController {

    private Connection conn;

    public CitaController() {
        conn = ConexionBD.getConnection();
    }

    public boolean registrarCita(Cita cita) {
        String sql = "INSERT INTO CITA (id_paciente, id_medico, fecha_hora, estado, motivo) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cita.getIdPaciente());
            stmt.setInt(2, cita.getIdMedico());
            stmt.setTimestamp(3, new Timestamp(cita.getFechaHora().getTime()));
            stmt.setString(4, cita.getEstado());
            stmt.setString(5, cita.getMotivo());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Error al registrar cita: " + ex.getMessage());
            return false;
        }
    }

    public List<Cita> listarCitas() {
        List<Cita> citas = new ArrayList<>();
        String sql = "SELECT * FROM CITA";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cita c = new Cita();
                c.setIdCita(rs.getInt("id_cita"));
                c.setIdPaciente(rs.getInt("id_paciente"));
                c.setIdMedico(rs.getInt("id_medico"));
                c.setFechaHora(rs.getTimestamp("fecha_hora"));
                c.setEstado(rs.getString("estado"));
                c.setMotivo(rs.getString("motivo"));
                citas.add(c);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar citas: " + ex.getMessage());
        }
        return citas;
    }

    public Cita obtenerCitaPorId(int idCita) {
        String sql = "SELECT * FROM CITA WHERE id_cita = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCita);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Cita(
                    rs.getInt("id_cita"),
                    rs.getInt("id_paciente"),
                    rs.getInt("id_medico"),
                    rs.getTimestamp("fecha_hora"),
                    rs.getString("estado"),
                    rs.getString("motivo")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener cita por ID: " + ex.getMessage());
        }
        return null;
    }

    public boolean actualizarCita(Cita cita) {
        String sql = "UPDATE CITA SET id_paciente=?, id_medico=?, fecha_hora=?, estado=?, motivo=? WHERE id_cita=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cita.getIdPaciente());
            stmt.setInt(2, cita.getIdMedico());
            stmt.setTimestamp(3, new Timestamp(cita.getFechaHora().getTime()));
            stmt.setString(4, cita.getEstado());
            stmt.setString(5, cita.getMotivo());
            stmt.setInt(6, cita.getIdCita());
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar cita: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminarCita(int idCita) {
        String sql = "DELETE FROM CITA WHERE id_cita = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCita);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar cita: " + ex.getMessage());
            return false;
        }
    }    
}
