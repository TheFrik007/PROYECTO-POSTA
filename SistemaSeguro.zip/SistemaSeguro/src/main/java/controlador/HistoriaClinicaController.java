
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.HistoriaClinica;
import utilidades.ConexionBD;

public class HistoriaClinicaController {
    
    private Connection conn;

    public HistoriaClinicaController() {
        conn = ConexionBD.getConnection();
    }

    public boolean registrarHistoria(HistoriaClinica historia) {
        String sql = "INSERT INTO HISTORIA_CLINICA (id_paciente, fecha_creacion, alergias, antecedentes) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, historia.getIdPaciente());
            stmt.setDate(2, new java.sql.Date(historia.getFechaCreacion().getTime()));
            stmt.setString(3, historia.getAlergias());
            stmt.setString(4, historia.getAntecedentes());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Error al registrar historia clínica: " + ex.getMessage());
            return false;
        }
    }

    public List<HistoriaClinica> listarHistorias() {
        List<HistoriaClinica> historias = new ArrayList<>();
        String sql = "SELECT * FROM HISTORIA_CLINICA";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                HistoriaClinica h = new HistoriaClinica();
                h.setIdHistoria(rs.getInt("id_historia"));
                h.setIdPaciente(rs.getInt("id_paciente"));
                h.setFechaCreacion(rs.getDate("fecha_creacion"));
                h.setAlergias(rs.getString("alergias"));
                h.setAntecedentes(rs.getString("antecedentes"));
                historias.add(h);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar historias clínicas: " + ex.getMessage());
        }
        return historias;
    }

    public HistoriaClinica obtenerHistoriaPorId(int idHistoria) {
        String sql = "SELECT * FROM HISTORIA_CLINICA WHERE id_historia = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idHistoria);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new HistoriaClinica(
                    rs.getInt("id_historia"),
                    rs.getInt("id_paciente"),
                    rs.getDate("fecha_creacion"),
                    rs.getString("alergias"),
                    rs.getString("antecedentes")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener historia clínica por ID: " + ex.getMessage());
        }
        return null;
    }

    public boolean actualizarHistoria(HistoriaClinica historia) {
        String sql = "UPDATE HISTORIA_CLINICA SET id_paciente=?, fecha_creacion=?, alergias=?, antecedentes=? WHERE id_historia=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, historia.getIdPaciente());
            stmt.setDate(2, new java.sql.Date(historia.getFechaCreacion().getTime()));
            stmt.setString(3, historia.getAlergias());
            stmt.setString(4, historia.getAntecedentes());
            stmt.setInt(5, historia.getIdHistoria());
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar historia clínica: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminarHistoria(int idHistoria) {
        String sql = "DELETE FROM HISTORIA_CLINICA WHERE id_historia = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idHistoria);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar historia clínica: " + ex.getMessage());
            return false;
        }
    }
}
