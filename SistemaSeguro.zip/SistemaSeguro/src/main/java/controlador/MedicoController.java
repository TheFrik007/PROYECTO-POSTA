
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Medico;
import utilidades.ConexionBD;

public class MedicoController {

    private Connection conn;

    public MedicoController() {
        conn = ConexionBD.getConnection();
    }

    public boolean registrarMedico(Medico medico) {
        String sql = "INSERT INTO MEDICO (id_usuario, especialidad, horario) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, medico.getIdUsuario());
            stmt.setString(2, medico.getEspecialidad());
            stmt.setString(3, medico.getHorario());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Error al registrar médico: " + ex.getMessage());
            return false;
        }
    }

    public List<Medico> listarMedicos() {
        List<Medico> medicos = new ArrayList<>();
        String sql = "SELECT * FROM MEDICO";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Medico m = new Medico();
                m.setIdMedico(rs.getInt("id_medico"));
                m.setIdUsuario(rs.getInt("id_usuario"));
                m.setEspecialidad(rs.getString("especialidad"));
                m.setHorario(rs.getString("horario"));
                medicos.add(m);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar médicos: " + ex.getMessage());
        }
        return medicos;
    }

    public Medico obtenerMedicoPorId(int idMedico) {
        String sql = "SELECT * FROM MEDICO WHERE id_medico = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idMedico);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Medico(
                    rs.getInt("id_medico"),
                    rs.getInt("id_usuario"),
                    rs.getString("especialidad"),
                    rs.getString("horario")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener médico por ID: " + ex.getMessage());
        }
        return null;
    }

    public boolean actualizarMedico(Medico medico) {
        String sql = "UPDATE MEDICO SET id_usuario=?, especialidad=?, horario=? WHERE id_medico=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, medico.getIdUsuario());
            stmt.setString(2, medico.getEspecialidad());
            stmt.setString(3, medico.getHorario());
            stmt.setInt(4, medico.getIdMedico());
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar médico: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminarMedico(int idMedico) {
        String sql = "DELETE FROM MEDICO WHERE id_medico = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idMedico);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar médico: " + ex.getMessage());
            return false;
        }
    }  
}
