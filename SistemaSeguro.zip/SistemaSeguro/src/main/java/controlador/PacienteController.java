/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Paciente;
import utilidades.ConexionBD;

public class PacienteController {
    private Connection conn;

    public PacienteController() {
        conn = ConexionBD.getConnection();
    }

public boolean registrarPaciente(Paciente paciente) {
    String sqlUsuario = "INSERT INTO usuario (nombre, correo, contraseña, rol) VALUES (?, ?, ?, ?)";
    String sqlPaciente = "INSERT INTO paciente (dni, nombre, apellido, fecha_nacimiento, genero, telefono, direccion, seguro, idUsuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try {
        conn.setAutoCommit(false); // Iniciar transacción

        // 1. Insertar usuario
        try (PreparedStatement stmtUsuario = conn.prepareStatement(sqlUsuario, Statement.RETURN_GENERATED_KEYS)) {
            stmtUsuario.setString(1, paciente.getNombre() + " " + paciente.getApellido());
            stmtUsuario.setString(2, paciente.getCorreo());
            stmtUsuario.setString(3, paciente.getContrasena());
            stmtUsuario.setString(4, "Usuario"); // Puedes ajustar el rol si usas otro para pacientes

            stmtUsuario.executeUpdate();

            ResultSet rs = stmtUsuario.getGeneratedKeys();
            if (rs.next()) {
                int idUsuario = rs.getInt(1);

                // 2. Insertar paciente con idUsuario
                try (PreparedStatement stmtPaciente = conn.prepareStatement(sqlPaciente)) {
                    stmtPaciente.setString(1, paciente.getDni());
                    stmtPaciente.setString(2, paciente.getNombre());
                    stmtPaciente.setString(3, paciente.getApellido());
                    stmtPaciente.setDate(4, new java.sql.Date(paciente.getFechaNacimiento().getTime()));
                    stmtPaciente.setString(5, paciente.getGenero());
                    stmtPaciente.setString(6, paciente.getTelefono());
                    stmtPaciente.setString(7, paciente.getDireccion());
                    stmtPaciente.setString(8, paciente.getSeguro());
                    stmtPaciente.setInt(9, idUsuario);
                    stmtPaciente.executeUpdate();
                }

                conn.commit(); // Confirmar transacción
                return true;
            } else {
                conn.rollback();
                System.err.println("No se pudo obtener el ID del nuevo usuario.");
                return false;
            }
        }

    } catch (SQLException ex) {
        try {
            conn.rollback(); // Revertir en caso de error
        } catch (SQLException e) {
            System.err.println("Error al hacer rollback: " + e.getMessage());
        }
        System.err.println("Error al registrar paciente y usuario: " + ex.getMessage());
        return false;
    } finally {
        try {
            conn.setAutoCommit(true); // Restaurar auto-commit
        } catch (SQLException e) {
            System.err.println("Error al restaurar auto-commit: " + e.getMessage());
        }
    }
}

    public List<Paciente> obtenerTodosLosPacientes() {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT * FROM PACIENTE";

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Paciente p = new Paciente();
                p.setIdPaciente(rs.getInt("id_paciente"));
                p.setDni(rs.getString("dni"));
                p.setNombre(rs.getString("nombre"));
                p.setApellido(rs.getString("apellido"));
                p.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                p.setGenero(rs.getString("genero"));
                p.setTelefono(rs.getString("telefono"));
                p.setDireccion(rs.getString("direccion"));
                p.setSeguro(rs.getString("seguro"));
                pacientes.add(p);
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener pacientes: " + ex.getMessage());
        }

        return pacientes;
    }

    public Paciente obtenerPacientePorDNI(String dni) {
        String sql = "SELECT * FROM PACIENTE WHERE dni = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, dni);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Paciente(
                    rs.getInt("id_paciente"),
                    rs.getString("dni"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getDate("fecha_nacimiento"),
                    rs.getString("genero"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("seguro")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al buscar paciente por DNI: " + ex.getMessage());
        }
        return null;
    }

    public boolean eliminarPaciente(int idPaciente) {
        String sql = "DELETE FROM PACIENTE WHERE id_paciente = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idPaciente);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar paciente: " + ex.getMessage());
            return false;
        }
    }

    public boolean actualizarPaciente(Paciente paciente) {
        String sql = "UPDATE PACIENTE SET dni=?, nombre=?, apellido=?, fecha_nacimiento=?, genero=?, telefono=?, direccion=?, seguro=? WHERE id_paciente=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, paciente.getDni());
            stmt.setString(2, paciente.getNombre());
            stmt.setString(3, paciente.getApellido());
            stmt.setDate(4, new java.sql.Date(paciente.getFechaNacimiento().getTime()));
            stmt.setString(5, paciente.getGenero());
            stmt.setString(6, paciente.getTelefono());
            stmt.setString(7, paciente.getDireccion());
            stmt.setString(8, paciente.getSeguro());
            stmt.setInt(9, paciente.getIdPaciente());
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar paciente: " + ex.getMessage());
            return false;
        }
    }
}
