/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Usuario;
import utilidades.ConexionBD;

public class UsuarioController {
    
    private Connection conn;

    public UsuarioController() {
        conn = ConexionBD.getConnection();
    }

    public boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO USUARIO (nombre_apellido, usuario, contrasena, id_rol) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreApellido());
            stmt.setString(2, usuario.getCorreo());
            stmt.setString(3, usuario.getContrasena());
            stmt.setInt(4, usuario.getIdRol());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("Error al registrar usuario: " + ex.getMessage());
            return false;
        }
    }

    public Usuario obtenerUsuarioPorCredenciales(String usuario, String contrasena) {
        String sql = "SELECT * FROM USUARIO WHERE usuario = ? AND contrasena = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario);
            stmt.setString(2, contrasena);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombre_apellido"),
                    rs.getString("usuario"),
                    rs.getString("contrasena"),
                    rs.getInt("id_rol")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error al autenticar usuario: " + ex.getMessage());
        }
        return null;
    }

    public List<Usuario> listarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM USUARIO";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Usuario u = new Usuario();
                u.setIdUsuario(rs.getInt("id_usuario"));
                u.setNombreApellido(rs.getString("nombre_apellido"));
                u.setCorreo(rs.getString("correo"));
                u.setContrasena(rs.getString("contrasena"));
                u.setIdRol(rs.getInt("id_rol"));
                usuarios.add(u);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar usuarios: " + ex.getMessage());
        }
        return usuarios;
    }

    public boolean eliminarUsuario(int idUsuario) {
        String sql = "DELETE FROM USUARIO WHERE id_usuario = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar usuario: " + ex.getMessage());
            return false;
        }
    }

    public boolean actualizarUsuario(Usuario usuario) {
        String sql = "UPDATE USUARIO SET nombre_apellido=?, usuario=?, contrasena=?, id_rol=? WHERE id_usuario=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNombreApellido());
            stmt.setString(2, usuario.getCorreo());
            stmt.setString(3, usuario.getContrasena());
            stmt.setInt(4, usuario.getIdRol());
            stmt.setInt(5, usuario.getIdUsuario());
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar usuario: " + ex.getMessage());
            return false;
        }
    }
}
