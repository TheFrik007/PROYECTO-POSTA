
package model;

import java.util.Date;

public class Diagnostico {
    private int idDiagnostico;
    private int idHistoria;
    private String descripcion;
    private Date fecha;

    public Diagnostico() {}

    public Diagnostico(int idDiagnostico, int idHistoria, String descripcion, Date fecha) {
        this.idDiagnostico = idDiagnostico;
        this.idHistoria = idHistoria;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }

    public int getIdDiagnostico() {
        return idDiagnostico;
    }

    public void setIdDiagnostico(int idDiagnostico) {
        this.idDiagnostico = idDiagnostico;
    }

    public int getIdHistoria() {
        return idHistoria;
    }

    public void setIdHistoria(int idHistoria) {
        this.idHistoria = idHistoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    
}
