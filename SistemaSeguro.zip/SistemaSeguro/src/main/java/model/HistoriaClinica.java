/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HistoriaClinica {
    private int idHistoria;
    private int idPaciente;
    private Date fechaCreacion;
    private String alergias;
    private String antecedentes;

    public HistoriaClinica() {}

    public HistoriaClinica(int idHistoria, int idPaciente, Date fechaCreacion, String alergias, String antecedentes) {
        this.idHistoria = idHistoria;
        this.idPaciente = idPaciente;
        this.fechaCreacion = fechaCreacion;
        this.alergias = alergias;
        this.antecedentes = antecedentes;
    }

    public int getIdHistoria() {
        return idHistoria;
    }

    public void setIdHistoria(int idHistoria) {
        this.idHistoria = idHistoria;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public String getAntecedentes() {
        return antecedentes;
    }

    public void setAntecedentes(String antecedentes) {
        this.antecedentes = antecedentes;
    }
    

}
