package model;

import java.util.List;

public class Medico extends Usuario{
    private int idMedico;
    private int idUsuario;
    private String especialidad;
    private String horario;

    public Medico() {}


    public Medico(int idMedico, int idUsuario, String especialidad, String horario) {
        this.idMedico = idMedico;
        this.idUsuario = idUsuario;
        this.especialidad = especialidad;
        this.horario = horario;
    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
    
    
    
}
