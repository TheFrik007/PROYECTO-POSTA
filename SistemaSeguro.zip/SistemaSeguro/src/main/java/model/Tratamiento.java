
package model;

import java.util.Date;

public class Tratamiento {
    private int idTratamiento;
    private int idHistoria;
    private String descripcion;
    private Date fechaInicio;
    private Date fechaFin;

    public Tratamiento() {}

    public Tratamiento(int idTratamiento, int idHistoria, String descripcion, Date fechaInicio, Date fechaFin) {
        this.idTratamiento = idTratamiento;
        this.idHistoria = idHistoria;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getIdTratamiento() {
        return idTratamiento;
    }

    public void setIdTratamiento(int idTratamiento) {
        this.idTratamiento = idTratamiento;
    }

    public int getIdHistoria() {
        return idHistoria;
    }

    public void setIdHistoria(int idHistoria) {
        this.idHistoria = idHistoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
    
    
}
