package utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexionBD {
     private static final String USUARIO = "root";
    private static final String CONTRASENIA = "";
    private static final String BD = "postadb";
    private static final String IP = "localhost";
    private static final String PUERTO = "3306";
    private static final String CADENA = "jdbc:mysql://" + IP + ":" + PUERTO + "/" + BD + "?useSSL=false&serverTimezone=UTC";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(CADENA, USUARIO, CONTRASENIA);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            return null;
        }
    }
}