package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FormularioRegistroManual extends JFrame {

    private JTextField txtApellidos, txtNombres, txtNumeroDoc, txtEdad, txtCelular, txtCorreo, txtDireccion;
    private JComboBox<String> cbTipoDoc, cbSexo, cbEstadoCivil, cbPais, cbDepartamento, cbProvincia, cbDistrito;
    private JRadioButton rbActivo, rbInactivo;
    private ButtonGroup grupoSeguro;
    private JButton btnGuardar, btnLimpiar;

    public FormularioRegistroManual() {
        setTitle("Registro de Paciente");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Datos del Paciente"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;

        // Fila 1
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Tipo de Documento:"), gbc);
        gbc.gridx = 1;
        cbTipoDoc = new JComboBox<>(new String[] {"DNI", "Carnet Ext.", "Pasaporte"});
        panel.add(cbTipoDoc, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("N° de Documento:"), gbc);
        gbc.gridx = 3;
        txtNumeroDoc = new JTextField(10);
        panel.add(txtNumeroDoc, gbc);

        // Fila 2
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 1;
        txtApellidos = new JTextField(15);
        panel.add(txtApellidos, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Edad:"), gbc);
        gbc.gridx = 3;
        txtEdad = new JTextField(5);
        panel.add(txtEdad, gbc);

        // Fila 3
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Nombres:"), gbc);
        gbc.gridx = 1;
        txtNombres = new JTextField(15);
        panel.add(txtNombres, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Celular:"), gbc);
        gbc.gridx = 3;
        txtCelular = new JTextField(10);
        panel.add(txtCelular, gbc);

        // Fila 4
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Dirección:"), gbc);
        gbc.gridx = 1;
        txtDireccion = new JTextField(20);
        gbc.gridwidth = 3;
        panel.add(txtDireccion, gbc);
        gbc.gridwidth = 1;

        // Fila 5
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Correo Electrónico:"), gbc);
        gbc.gridx = 1;
        txtCorreo = new JTextField(15);
        panel.add(txtCorreo, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Sexo:"), gbc);
        gbc.gridx = 3;
        cbSexo = new JComboBox<>(new String[] {"Masculino", "Femenino"});
        panel.add(cbSexo, gbc);

        // Fila 6
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Seguro:"), gbc);
        gbc.gridx = 1;
        rbActivo = new JRadioButton("Activo");
        rbInactivo = new JRadioButton("Inactivo");
        grupoSeguro = new ButtonGroup();
        grupoSeguro.add(rbActivo);
        grupoSeguro.add(rbInactivo);
        JPanel panelSeguro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSeguro.add(rbActivo);
        panelSeguro.add(rbInactivo);
        panel.add(panelSeguro, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Estado Civil:"), gbc);
        gbc.gridx = 3;
        cbEstadoCivil = new JComboBox<>(new String[] {"Soltero", "Casado", "Divorciado", "Viudo"});
        panel.add(cbEstadoCivil, gbc);

        // Fila 7
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("País:"), gbc);
        gbc.gridx = 1;
        cbPais = new JComboBox<>(new String[] {"PERU"});
        panel.add(cbPais, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Departamento:"), gbc);
        gbc.gridx = 3;
        cbDepartamento = new JComboBox<>(new String[] {"Lima", "Cusco", "Arequipa"});
        panel.add(cbDepartamento, gbc);

        // Fila 8
        gbc.gridx = 0; gbc.gridy++;
        panel.add(new JLabel("Provincia:"), gbc);
        gbc.gridx = 1;
        cbProvincia = new JComboBox<>(new String[] {"Lima", "Urubamba", "Camaná"});
        panel.add(cbProvincia, gbc);

        gbc.gridx = 2;
        panel.add(new JLabel("Distrito:"), gbc);
        gbc.gridx = 3;
        cbDistrito = new JComboBox<>(new String[] {"Lince", "Miraflores", "San Borja"});
        panel.add(cbDistrito, gbc);

        // Botones
        JPanel panelBotones = new JPanel();
        btnGuardar = new JButton("Guardar");
        btnLimpiar = new JButton("Limpiar");
        panelBotones.add(btnGuardar);
        panelBotones.add(btnLimpiar);

        add(panel, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Acción de los botones
        btnGuardar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Paciente guardado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        });

        btnLimpiar.addActionListener(e -> limpiarCampos());
    }

    private void limpiarCampos() {
        txtNumeroDoc.setText("");
        txtApellidos.setText("");
        txtNombres.setText("");
        txtEdad.setText("");
        txtCelular.setText("");
        txtDireccion.setText("");
        txtCorreo.setText("");
        cbTipoDoc.setSelectedIndex(0);
        cbSexo.setSelectedIndex(0);
        cbEstadoCivil.setSelectedIndex(0);
        cbPais.setSelectedIndex(0);
        cbDepartamento.setSelectedIndex(0);
        cbProvincia.setSelectedIndex(0);
        cbDistrito.setSelectedIndex(0);
        grupoSeguro.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FormularioRegistroManual().setVisible(true));
    }
}
