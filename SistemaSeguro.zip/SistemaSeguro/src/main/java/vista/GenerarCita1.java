package vista;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class GenerarCita1 extends JFrame {

    private final JLabel lblTitulo;
    private final JLabel lblEspecialidad;
    private final JLabel lblHorario;
    private final JComboBox<String> cmbEspecialidad;
    private final JButton btnBuscar;
    private final JButton btnGenerarCita;
    private final JTable tblHorarios;
    private final JScrollPane scrollPane;

    public GenerarCita1() {
        setTitle("Generación de Cita");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        lblTitulo = new JLabel("GENERACION DE CITA");
        lblTitulo.setBounds(20, 10, 200, 30);
        lblTitulo.setForeground(Color.BLUE);

        lblEspecialidad = new JLabel("SELECCIONAR ESPECIALIDAD");
        lblEspecialidad.setBounds(80, 60, 250, 20);

        lblHorario = new JLabel("HORARIOS DISPONIBLES: (REEMPLAZAR CON CALENDARIO)");
        lblHorario.setBounds(80, 130, 400, 20);

        cmbEspecialidad = new JComboBox<>();
        cmbEspecialidad.setBounds(80, 85, 250, 25);
        cmbEspecialidad.addItem("Medicina General");
        cmbEspecialidad.addItem("Pediatría");
        cmbEspecialidad.addItem("Dermatología");
        cmbEspecialidad.addItem("Odontología");

        btnBuscar = new JButton("BUSCAR");
        btnBuscar.setBounds(340, 85, 100, 25);
        btnBuscar.addActionListener((ActionEvent e) -> {
            String especialidad = (String) cmbEspecialidad.getSelectedItem();
            JOptionPane.showMessageDialog(null,
                    "Mostrando horarios disponibles para: " + especialidad,
                    "Información", JOptionPane.INFORMATION_MESSAGE);
            cargarHorarios(especialidad);
        });

        String[] columnas = {"LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO", "DOMINGO"};
        String[][] datos = new String[3][7];
        tblHorarios = new JTable(datos, columnas);
        scrollPane = new JScrollPane(tblHorarios);
        scrollPane.setBounds(80, 160, 580, 150);

        btnGenerarCita = new JButton("GENERAR CITA");
        btnGenerarCita.setBounds(80, 330, 150, 30);
        btnGenerarCita.addActionListener((ActionEvent e) -> {
            int fila = tblHorarios.getSelectedRow();
            int columna = tblHorarios.getSelectedColumn();

            if (fila >= 0 && columna >= 0) {
                String dia = tblHorarios.getColumnName(columna);
                String hora = (String) tblHorarios.getValueAt(fila, columna);

                if (hora != null && !hora.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null,
                            "Cita generada para el día " + dia + " a las " + hora,
                            "Cita Confirmada", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Seleccione un horario válido.",
                            "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null,
                        "Debe seleccionar un horario en la tabla.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(lblTitulo);
        add(lblEspecialidad);
        add(cmbEspecialidad);
        add(btnBuscar);
        add(lblHorario);
        add(scrollPane);
        add(btnGenerarCita);
    }

    private void cargarHorarios(String especialidad) {
        String[][] datos = {
            {"8:00", "9:00", "10:00", "11:00", "", "", ""},
            {"", "9:30", "", "11:30", "", "", ""},
            {"8:30", "", "", "10:30", "12:00", "", ""}
        };

        for (int i = 0; i < tblHorarios.getRowCount(); i++) {
            for (int j = 0; j < tblHorarios.getColumnCount(); j++) {
                if (i < datos.length && j < datos[i].length) {
                    tblHorarios.setValueAt(datos[i][j], i, j);
                } else {
                    tblHorarios.setValueAt("", i, j);
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GenerarCita1().setVisible(true));
    }
}