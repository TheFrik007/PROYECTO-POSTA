/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vista;

public class Interfaces {

    public static void main(String[] args) {
        Login objetoLogin = new Login();
        objetoLogin.setVisible(true);
    }
}
