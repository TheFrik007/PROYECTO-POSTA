package vista;

import javax.swing.*;

public class LoginManual extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar, btnSalir;

    public LoginManual() {
        setTitle("Inicio de Sesión");
        setSize(300, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel lblUsuario = new JLabel("USUARIO");
        lblUsuario.setBounds(30, 30, 80, 25);
        panel.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(120, 30, 130, 25);
        panel.add(txtUsuario);

        JLabel lblContrasena = new JLabel("CONTRASEÑA");
        lblContrasena.setBounds(30, 70, 100, 25);
        panel.add(lblContrasena);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(120, 70, 130, 25);
        panel.add(txtContrasena);

        btnIngresar = new JButton("INGRESAR");
        btnIngresar.setBounds(30, 120, 100, 30);
        panel.add(btnIngresar);

        btnSalir = new JButton("SALIR");
        btnSalir.setBounds(150, 120, 100, 30);
        panel.add(btnSalir);

        // Acción botón salir
        btnSalir.addActionListener(e -> System.exit(0));

        this.add(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginManual().setVisible(true);
        });
    }
}